const changeTitle = (newTitle) => {
  document.title = newTitle
}
export default changeTitle
